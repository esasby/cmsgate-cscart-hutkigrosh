{$configForm->generate() nofilter}

{assign var="hgPP" value=[]}
{if $mainPaymentMethod}
    {assign var="hgPPtmp" value=$mainPaymentMethod->getProcessorParams()}
    {if $hgPPtmp}
        {assign var="hgPP" value=$hgPPtmp}
    {/if}
{/if}

{* hg_metadata_json хранится в БД как JSON, а в форму отдаётся в base64url (см. payments.post.php),
   чтобы сырой JSON не блокировался firewall/WAF при сохранении настроек. *}
<input type="hidden" name="payment_data[processor_params][hg_metadata_json]" id="hg_metadata_json"
       value="{$hg_metadata_b64|default:''|escape}">

{script src="js/lib/jquery/jquery.min.js"}
<script type="text/javascript">
var hgSavedService = '{$hgPP.service_id|default:''}';
var hgSavedOutlet = '{$hgPP.retail_outlet_id|default:''}';
var hgSavedCashbox = '{$hgPP.cash_box_id|default:''}';

{literal}
(function($) {
    $(document).ready(function() {
        var tokenField = $('#hg_api_token');
        if (tokenField.length === 0) return;

        var refreshBtn = $('<button type="button" class="btn btn-primary" id="hg_load_metadata">Актуализировать</button>');
        var statusLabel = $('<span id="hg_metadata_status" style="margin-left: 10px;"></span>');
        var btnGroup = $('<div class="control-group"><div class="controls"></div></div>');
        btnGroup.find('.controls').append(refreshBtn).append(statusLabel);
        tokenField.closest('.control-group').after(btnGroup);

        var sandboxCheckbox = $('input[type="checkbox"][name*="sandbox"]');
        var metadataField = $('#hg_metadata_json');

        var savedValues = {
            service_id: hgSavedService,
            retail_outlet_id: hgSavedOutlet,
            cash_box_id: hgSavedCashbox
        };

        // base64url <-> строка (UTF-8-безопасно: в названиях услуг/точек может быть кириллица).
        // btoa работает только с Latin1, поэтому кодируем через UTF-8 (encodeURIComponent/unescape).
        function hgB64UrlEncode(str) {
            return btoa(unescape(encodeURIComponent(str)))
                .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
        }
        function hgB64UrlDecode(str) {
            var s = String(str).replace(/-/g, '+').replace(/_/g, '/');
            while (s.length % 4) s += '=';
            return decodeURIComponent(escape(atob(s)));
        }

        // При загрузке страницы — восстановить селекты из метаданных в скрытом поле.
        // Поле приходит в base64url, но для устойчивости поддерживаем также сырой JSON
        // и двойной base64url (могут остаться после предыдущих версий/кэша/старого сохранения).
        function hgParseMetadata(raw) {
            if (!raw) return null;
            var candidate = String(raw);
            for (var i = 0; i < 3; i++) {
                if (candidate.charAt(0) === '{') {
                    try { return JSON.parse(candidate); } catch (e) { return null; }
                }
                try { candidate = hgB64UrlDecode(candidate); } catch (e) { return null; }
            }
            return null;
        }

        var storedData = hgParseMetadata(metadataField.val());
        if (storedData) {
            // Нормализуем поле в чистый base64url, чтобы при сохранении данные были консистентны.
            try { metadataField.val(hgB64UrlEncode(JSON.stringify(storedData))); } catch (e) {}
            // Заполняем опции и выбираем именно сохранённые ранее значения (см. savedValues).
            populateSelects(storedData, savedValues);
        }

        refreshBtn.on('click', function() {
            var token = tokenField.val();
            if (!token) {
                alert('Введите API Токен');
                return;
            }

            statusLabel.text('Загрузка данных...');
            statusLabel.css('color', 'blue');

            var sandbox = sandboxCheckbox.is(':checked');

            $.ajax({
                url: fn_url('hutkigrosh.metadata'),
                type: 'GET',
                data: {
                    api_token_hg: token,
                    sandbox: sandbox
                },
                dataType: 'json',
                success: function(data) {
                    if (data.error) {
                        statusLabel.text('Ошибка: ' + data.error);
                        statusLabel.css('color', 'red');
                        return;
                    }

                    // Сохраняем метаданные в скрытое поле в base64url (firewall/WAF не блокирует)
                    metadataField.val(hgB64UrlEncode(JSON.stringify(data)));
                    // Автозаполнение первыми доступными данными из API v3
                    populateSelects(data, {});

                    statusLabel.text('Данные загружены успешно');
                    statusLabel.css('color', 'green');
                },
                error: function(xhr) {
                    statusLabel.text('Ошибка загрузки данных');
                    statusLabel.css('color', 'red');
                }
            });
        });

        function populateSelects(data, selected) {
            var serviceSelect = $('#service_id');
            var outletSelect = $('#retail_outlet_id');
            var cashboxSelect = $('#cash_box_id');

            // Селекты изначально пустые (без плейсхолдера «—»). После добавления опций браузер
            // автоматически выбирает первую; сохранённое значение (если есть) переопределяет выбор.

            // Услуги
            serviceSelect.empty();
            if (data.services) {
                $.each(data.services, function(i, s) {
                    serviceSelect.append('<option value="' + s.code + '">' + s.code + ' — ' + (s.name || '') + '</option>');
                });
                if (selected.service_id) serviceSelect.val(selected.service_id);
            }

            // Розничные точки
            if (outletSelect.length && data.retailOutlets) {
                outletSelect.empty();
                $.each(data.retailOutlets, function(i, o) {
                    outletSelect.append('<option value="' + o.code + '">' + o.code + ' — ' + (o.name || '') + '</option>');
                    outletSelect.find('option:last').data('cashboxes', o.cashBoxes || []);
                });
                if (selected.retail_outlet_id) outletSelect.val(selected.retail_outlet_id);

                // При выборе точки — обновляем кассовые места
                outletSelect.off('change').on('change', function() {
                    if (cashboxSelect.length) {
                        cashboxSelect.empty();
                        var cashboxes = outletSelect.find('option:selected').data('cashboxes') || [];
                        $.each(cashboxes, function(i, c) {
                            cashboxSelect.append('<option value="' + c.code + '">' + c.code + ' — ' + (c.name || '') + '</option>');
                        });
                        if (selected.cash_box_id) {
                            cashboxSelect.val(selected.cash_box_id);
                            selected.cash_box_id = '';
                        }
                    }
                });

                // Загружаем кассовые места для текущей точки (первой или сохранённой)
                outletSelect.trigger('change');
            } else if (cashboxSelect.length) {
                cashboxSelect.empty();
            }
        }
    });
})(jQuery);
{/literal}
</script>
