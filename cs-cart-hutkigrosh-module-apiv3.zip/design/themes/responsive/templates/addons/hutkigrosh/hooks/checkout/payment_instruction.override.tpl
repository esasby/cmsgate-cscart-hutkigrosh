{if !empty($completionPanel)}
    {$completionPanel->build() nofilter}
{elseif !empty($completionPanelWebpay)}
    {$completionPanelWebpay->redirectWebpay() nofilter}
{/if}
