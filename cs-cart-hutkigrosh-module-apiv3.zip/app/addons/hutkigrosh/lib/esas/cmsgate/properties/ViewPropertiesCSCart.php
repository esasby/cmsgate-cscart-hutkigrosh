<?php

namespace esas\cmsgate\properties;

use esas\cmsgate\properties\ViewProperties;

class ViewPropertiesCSCart implements ViewProperties
{
    public function getBootstrapVersion()
    {
        return ViewProperties::BOOTSTRAP_V5;
    }
}
