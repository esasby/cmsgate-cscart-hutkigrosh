<?php

namespace esas\cmsgate;

use esas\cmsgate\descriptors\ModuleDescriptor;
use esas\cmsgate\descriptors\VendorDescriptor;
use esas\cmsgate\descriptors\VersionDescriptor;
use esas\cmsgate\hutkigrosh\ConfigFieldsHutkigrosh;
use esas\cmsgate\hutkigrosh\PaysystemConnectorHutkigrosh;
use esas\cmsgate\hutkigrosh\RegistryHutkigrosh;
use esas\cmsgate\hutkigrosh\hro\client\CompletionPanelHutkigroshHRO;
use esas\cmsgate\hro\HROManager;
use esas\cmsgate\properties\ViewPropertiesCSCart;
use esas\cmsgate\view\admin\AdminViewFields;
use esas\cmsgate\view\admin\ConfigFormCSCart;
use esas\cmsgate\view\client\CompletionPanelHutkigroshCSCart;

class RegistryHutkigroshCSCart extends RegistryHutkigrosh
{
    public function __construct()
    {
        $this->cmsConnector = new CmsConnectorCSCart();
        $this->paysystemConnector = new PaysystemConnectorHutkigrosh();
    }

    public function init()
    {
        parent::init();
        HROManager::fromRegistry()->addImplementation(CompletionPanelHutkigroshHRO::class, CompletionPanelHutkigroshCSCart::class);
    }

    /**
     * @return RegistryHutkigroshCSCart
     */
    public static function getRegistry()
    {
        return parent::getRegistry();
    }

    /**
     * @return ConfigFormCSCart
     */
    public function getConfigForm()
    {
        return parent::getConfigForm();
    }

    public function createConfigForm()
    {
        $managedFields = $this->getManagedFieldsFactory()->getManagedFieldsExcept(AdminViewFields::CONFIG_FORM_COMMON,
            [
                ConfigFieldsHutkigrosh::shopName(),
                ConfigFieldsHutkigrosh::useOrderNumber(),
                ConfigFieldsHutkigrosh::paymentMethodName(),
                ConfigFieldsHutkigrosh::paymentMethodDetails(),
                ConfigFieldsHutkigrosh::paymentMethodNameWebpay(),
                ConfigFieldsHutkigrosh::paymentMethodDetailsWebpay()
            ]);
        $configForm = new ConfigFormCSCart(
            AdminViewFields::CONFIG_FORM_COMMON,
            $managedFields);
        return $configForm;
    }

    public function getCompletionPanel($orderWrapper)
    {
        HROManager::fromRegistry()->addImplementation(CompletionPanelHutkigroshHRO::class, CompletionPanelHutkigroshCSCart::class);
        return CompletionPanelHutkigroshCSCart::builder();
    }

    function getUrlWebpay($orderWrapper)
    {
        return REAL_URL;
    }

    public function createModuleDescriptor()
    {
        return new ModuleDescriptor(
            "hutkigrosh",
            new VersionDescriptor("4.0.0", "2025-05-19"),
            "Прием платежей через ЕРИП (сервис Hutkigrosh)",
            "https://bitbucket.esas.by/projects/CG/repos/cmsgate-cscart-hutkigrosh/browse",
            VendorDescriptor::esas(),
            "Выставление пользовательских счетов в ЕРИП"
        );
    }

    const PAYMENT_PROCESSOR_NAME_HUTKIGROSH = "Hutkigrosh";
    const PAYMENT_PROCESSOR_NAME_WEBPAY = "Hutkigrosh Card";

    public function createProperties()
    {
        return new ViewPropertiesCSCart();
    }
}
