<?php

namespace esas\cmsgate\view\client;

use esas\cmsgate\hutkigrosh\hro\client\CompletionPanelHutkigroshHRO_v1;
use esas\cmsgate\Registry;

class CompletionPanelHutkigroshCSCart extends CompletionPanelHutkigroshHRO_v1
{
    public static function builder()
    {
        return new CompletionPanelHutkigroshCSCart();
    }

    public function build()
    {
        if (!$this->orderCanBePayed) {
            return $this->renderMessages();
        }
        return parent::build();
    }

    protected function renderMessages()
    {
        $messenger = Registry::getRegistry()->getMessenger();
        $html = '';
        foreach ($messenger->getSuccessMessagesArray() as $message) {
            $html .= '<div style="background:#e8f5e9;border:1px solid #c8e6c9;border-radius:4px;padding:15px 20px;margin:10px 0;color:#2e7d32;font-size:14px;">'
                . $message . '</div>';
        }
        foreach ($messenger->getErrorMessagesArray() as $message) {
            $html .= '<div style="background:#ffebee;border:1px solid #ffcdd2;border-radius:4px;padding:15px 20px;margin:10px 0;color:#c62828;font-size:14px;">'
                . $message . '</div>';
        }
        foreach ($messenger->getWarnMessagesArray() as $message) {
            $html .= '<div style="background:#fff8e1;border:1px solid #ffecb3;border-radius:4px;padding:15px 20px;margin:10px 0;color:#f57f17;font-size:14px;">'
                . $message . '</div>';
        }
        foreach ($messenger->getInfoMessagesArray() as $message) {
            $html .= '<div style="background:#e3f2fd;border:1px solid #bbdefb;border-radius:4px;padding:15px 20px;margin:10px 0;color:#1565c0;font-size:14px;">'
                . $message . '</div>';
        }
        return $html;
    }

    public function isTabChecked($tabKey)
    {
        return false;
    }

    public function elementAlfaclickTab()
    {
        return "";
    }

    public function addCss()
    {
        return array($this->accordionStyles() . $this->accordionScript());
    }

    protected function accordionStyles()
    {
        return <<<'CSS'
<style>
.accordion .accordion-item {
    border: 1px solid #dee2e6;
    border-radius: 4px;
    margin-bottom: -1px;
}
.accordion .accordion-item:first-child {
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
}
.accordion .accordion-item:last-child {
    margin-bottom: 0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
}
.accordion .accordion-header .accordion-button {
    display: flex;
    align-items: center;
    width: 100%;
    padding: 12px 20px;
    font-size: 14px;
    font-weight: 600;
    color: #333;
    background: #f8f9fa;
    border: none;
    cursor: pointer;
    text-align: left;
    transition: background 0.2s;
}
.accordion .accordion-header .accordion-button:hover {
    background: #e9ecef;
}
.accordion .accordion-header .accordion-button::after {
    content: '';
    margin-left: auto;
    width: 0;
    height: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid #555;
    transition: transform 0.2s;
}
.accordion .accordion-header .accordion-button[aria-expanded="true"]::after {
    transform: rotate(180deg);
}
.accordion .accordion-collapse {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
}
.accordion .accordion-collapse.show {
    max-height: 2000px;
}
.accordion .accordion-body {
    padding: 15px 20px;
    border-top: 1px solid #dee2e6;
}
</style>
CSS;
    }

    protected function accordionScript()
    {
        return <<<'JS'
<script>
(function() {
    document.addEventListener('click', function(e) {
        var btn = e.target.closest('.accordion .accordion-button');
        if (!btn) return;
        var target = btn.getAttribute('data-bs-target');
        if (!target) return;
        var panel = document.querySelector(target);
        if (!panel) return;
        var isOpen = panel.classList.contains('show');
        panel.classList.toggle('show');
        btn.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
    });
})();
</script>
JS;
    }
}
