<?php

use esas\cmsgate\hutkigrosh\controllers\ControllerHutkigroshAddBill;
use esas\cmsgate\Registry;
use esas\cmsgate\wrappers\OrderWrapperCSCart;

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}
if ($mode == 'place_order') {
    try {
        $orderWrapper = new OrderWrapperCSCart($order_info);
        $controller = new ControllerHutkigroshAddBill();
        $resp = $controller->process($orderWrapper);
        if (!empty($resp->getBillId())) {
            $pp_response['order_status'] = Registry::getRegistry()->getConfigWrapper()->getOrderStatusPending();
            $pp_response['transaction_id'] = $resp->getBillId();
        } else {
            $pp_response['order_status'] = Registry::getRegistry()->getConfigWrapper()->getOrderStatusFailed();
            $pp_response['reason_text'] = $resp->getResponseMessage() ?: 'Не удалось выставить счёт';
        }
    } catch (Throwable $e) {
        $pp_response['order_status'] = 'F';
        $pp_response['reason_text'] = $e->getMessage();
    }
}
