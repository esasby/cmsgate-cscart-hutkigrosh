<?php

use esas\cmsgate\hutkigrosh\controllers\ControllerHutkigroshNotify;
use esas\cmsgate\utils\Logger;

if ($mode == 'notify') {
    try {
        $controller = new ControllerHutkigroshNotify();
        $controller->process();
    } catch (Throwable $e) {
        Logger::getLogger("callback")->error("Exception:", $e);
    }
    exit;
}
