<?php

use esas\cmsgate\hutkigrosh\controllers\ControllerHutkigroshCompletionPanel;
use esas\cmsgate\hutkigrosh\controllers\ControllerHutkigroshCompletionPanelWebpay;
use esas\cmsgate\hutkigrosh\utils\RequestParamsHutkigrosh;
use esas\cmsgate\RegistryHutkigroshCSCart;
use esas\cmsgate\utils\RequestParamsCSCart;
use esas\cmsgate\utils\Logger;

if ($mode == 'complete') {
    $orderId = $_REQUEST[RequestParamsCSCart::ORDER_ID];
    if (!empty($orderId)) {
        try {
            $order_info = fn_get_order_info($orderId);
            $processor = strtolower($order_info["payment_method"]["processor"]);
            if ($processor == strtolower(RegistryHutkigroshCSCart::PAYMENT_PROCESSOR_NAME_HUTKIGROSH)
                || ($processor == strtolower(RegistryHutkigroshCSCart::PAYMENT_PROCESSOR_NAME_WEBPAY) && array_key_exists(RequestParamsHutkigrosh::WEBPAY_STATUS, $_REQUEST)) ) {
                $controller = new ControllerHutkigroshCompletionPanel();
                $completionPanel = $controller->process($orderId);
                Tygh::$app['view']->assign('completionPanel', $completionPanel);
            } elseif ($processor == strtolower(RegistryHutkigroshCSCart::PAYMENT_PROCESSOR_NAME_WEBPAY)) {
                $controller = new ControllerHutkigroshCompletionPanelWebpay();
                $completionPanel = $controller->process($orderId);
                Tygh::$app['view']->assign('completionPanelWebpay', $completionPanel);
            }
        } catch (Throwable $e) {
            Logger::getLogger("complete")->error("Exception:", $e);
        }
    }
}
