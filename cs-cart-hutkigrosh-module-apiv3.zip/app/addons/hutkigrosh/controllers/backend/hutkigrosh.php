<?php

use esas\cmsgate\hutkigrosh\protocol\HutkigroshProtocol;
use esas\cmsgate\hutkigrosh\protocol\HutkigroshRq;
use esas\cmsgate\hutkigrosh\wrappers\ConfigWrapperHutkigrosh;
use esas\cmsgate\ConfigStorageCms;

if ($mode == 'metadata') {
    try {
        $apiToken = $_REQUEST['api_token_hg'];
        $sandbox = isset($_REQUEST['sandbox']) ? filter_var($_REQUEST['sandbox'], FILTER_VALIDATE_BOOLEAN) : false;
        header('Content-Type: application/json; charset=utf-8');

        if (empty($apiToken)) {
            echo json_encode(['error' => 'API Токен не указан']);
            exit;
        }

        $configStorage = new class($apiToken, $sandbox) extends ConfigStorageCms {
            private $token;
            private $sandboxMode;
            public function __construct($token, $sandbox) {
                parent::__construct();
                $this->token = $token;
                $this->sandboxMode = $sandbox;
            }
            public function getConfig($key) {
                if ($key === 'hg_api_token') return $this->token;
                if ($key === 'sandbox') return $this->sandboxMode ? 'Y' : 'N';
                if ($key === 'debug_mode') return 'N';
                return null;
            }
            public function saveConfig($key, $value) {
                return false;
            }
            public function convertToBoolean($cmsConfigValue) {
                return strtolower($cmsConfigValue) === 'y';
            }
            public function isStorageInitialised($key) {
                return !empty($this->getConfig($key));
            }
        };

        $configWrapper = new ConfigWrapperHutkigrosh($configStorage);
        $hg = new HutkigroshProtocol($configWrapper);
        $rq = new HutkigroshRq();
        $hg->checkProviderMetadata($rq);

        $result = [
            'services' => $rq->getServices() ?: [],
            'retailOutlets' => $rq->getRetailOutlets() ?: [],
        ];

        echo json_encode($result);
    } catch (Throwable $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}
