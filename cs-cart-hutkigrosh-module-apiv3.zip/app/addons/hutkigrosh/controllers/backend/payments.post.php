<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 28.02.2018
 * Time: 17:51
 */


use esas\cmsgate\CmsConnectorCSCart;
use esas\cmsgate\Registry;

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

if ($mode == 'processor') {
    $configForm = Registry::getRegistry()->getConfigForm();
    $mainPaymentMethod = CmsConnectorCSCart::getInstance()->getMainPaymentMethod(); //для отображения названия
    Tygh::$app['view']->assign('configForm', $configForm);
    Tygh::$app['view']->assign('mainPaymentMethod', $mainPaymentMethod);

    // hg_metadata_json хранится в БД как JSON. В скрытое поле отдаём его в base64url,
    // чтобы сырой JSON не блокировался firewall/WAF при следующем сохранении настроек.
    $processorParams = $mainPaymentMethod && is_array($mainPaymentMethod->getProcessorParams())
        ? $mainPaymentMethod->getProcessorParams()
        : array();
    $metadataJson = isset($processorParams['hg_metadata_json']) ? (string)$processorParams['hg_metadata_json'] : '';
    Tygh::$app['view']->assign('hg_metadata_b64', $metadataJson !== '' ? hg_base64url_encode($metadataJson) : '');
}