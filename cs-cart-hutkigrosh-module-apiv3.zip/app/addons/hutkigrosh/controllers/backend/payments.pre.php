<?php
/**
 * Pre-контроллер для payments: выполняется ДО сохранения настроек способа оплаты
 * (ядро вызывает fn_update_payment($_REQUEST['payment_data'], ...)).
 *
 * Скрытое поле hg_metadata_json приходит из формы в base64url, чтобы сырой JSON
 * не блокировался firewall/WAF при сохранении. Здесь декодируем base64url обратно
 * в JSON — эти данные нужны для заполнения селектов при последующей загрузке настроек.
 */

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    return;
}

if (!isset($_REQUEST['payment_data']['processor_params'])
    || !is_array($_REQUEST['payment_data']['processor_params'])
) {
    return;
}

$metadataB64 = isset($_REQUEST['payment_data']['processor_params']['hg_metadata_json'])
    ? $_REQUEST['payment_data']['processor_params']['hg_metadata_json']
    : '';

if (!is_string($metadataB64) || $metadataB64 === '') {
    return;
}

$decoded = hg_base64url_decode($metadataB64);
if ($decoded === '' || $decoded === false) {
    return;
}

// Сохраняем только валидный JSON — иначе селекты не смогут его разобрать при загрузке.
json_decode($decoded);
if (json_last_error() === JSON_ERROR_NONE) {
    $_REQUEST['payment_data']['processor_params']['hg_metadata_json'] = $decoded;
}
