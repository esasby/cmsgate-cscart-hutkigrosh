<?php

require_once(dirname(__FILE__) . '/init.php');

use esas\cmsgate\cscart\CSCartInstallHelper;
use esas\cmsgate\cscart\CSCartPaymentMethod;
use esas\cmsgate\cscart\CSCartPaymentProcessor;
use esas\cmsgate\hutkigrosh\ConfigFieldsHutkigrosh;
use esas\cmsgate\Registry;
use esas\cmsgate\RegistryHutkigroshCSCart;

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}
function fn_hutkigrosh_install()
{
    CSCartInstallHelper::uninstallDb();
    $mainProcessor = new CSCartPaymentProcessor();
    $mainProcessor->initDefaults();
    $mainProcessor->setProcessorName(RegistryHutkigroshCSCart::PAYMENT_PROCESSOR_NAME_HUTKIGROSH);
    $mainProcessor->setTemplate('views/orders/components/payments/cc_outside.tpl');
    $mainPaymentMethod = new CSCartPaymentMethod();
    $mainPaymentMethod->initDefaults();
    $mainPaymentMethod->setLogo('hutkigrosh.png');
    $mainPaymentMethod->setProcessor($mainProcessor);
    CSCartInstallHelper::addPaymentMethod($mainPaymentMethod);

    $webpayProcessor = new CSCartPaymentProcessor();
    $webpayProcessor->initDefaults();
    $webpayProcessor->setProcessorName(RegistryHutkigroshCSCart::PAYMENT_PROCESSOR_NAME_WEBPAY);
    $webpayProcessor->setTemplate('views/orders/components/payments/cc_outside.tpl');
    $webpayProcessor->setAdminTemplate('hutkigrosh_webpay.tpl');
    $webpayPaymentMethod = new CSCartPaymentMethod();
    $webpayPaymentMethod->initDefaults();
    $webpayPaymentMethod->setLogo('hutkigrosh_webpay.png');
    $webpayPaymentMethod->setProcessor($webpayProcessor);
    $webpayPaymentMethod->setName(Registry::getRegistry()->getTranslator()->getConfigFieldDefault(ConfigFieldsHutkigrosh::paymentMethodNameWebpay()));
    $webpayPaymentMethod->setDescription(Registry::getRegistry()->getTranslator()->getConfigFieldDefault(ConfigFieldsHutkigrosh::paymentMethodDetailsWebpay()));
    CSCartInstallHelper::addPaymentMethod($webpayPaymentMethod);
}

function fn_hutkigrosh_uninstall(){
    CSCartInstallHelper::uninstallDb();
}

/**
 * Кодирование строки в base64url (RFC 4648 §5): без символов "+", "/" и "=".
 * Применяется для скрытого поля hg_metadata_json — сырой JSON блокируется firewall/WAF
 * при сохранении настроек, а base64url состоит только из безопасных [A-Za-z0-9_-].
 *
 * @param string $data
 * @return string
 */
function hg_base64url_encode($data)
{
    return rtrim(strtr(base64_encode((string)$data), '+/', '-_'), '=');
}

/**
 * Обратное декодирование base64url в исходную строку (JSON).
 *
 * @param string $data
 * @return string|false
 */
function hg_base64url_decode($data)
{
    if ($data === null || $data === '') {
        return '';
    }
    $padded = strtr((string)$data, '-_', '+/');
    $remainder = strlen($padded) % 4;
    if ($remainder) {
        $padded .= str_repeat('=', 4 - $remainder);
    }
    return base64_decode($padded);
}
